class AddCourseRefToEvalution < ActiveRecord::Migration[5.0]
  def change
    add_reference :evaluations, :course, index: true, foreign_key:true
  end
end
