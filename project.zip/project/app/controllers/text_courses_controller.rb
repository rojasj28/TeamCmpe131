class TextCoursesController < ApplicationController
  def new
    @text_course =TextCourse.new
  end

  def create
    @text_course=current_user.text_courses.build(text_course_params)
    if @text_course.save
      redirect_to course_path(@text_course), notice: "Course Created"
    else render :new, alert: "Error Creating Course"
    end
  end
  def edit
    @text_course = current_user.text_courses.find(params[:id])
  end
  def update
    @text_course = current_user.text_courses.find(params[:id])
    if @text_course.update(text_course_params)
      redirect_to course_path(@text_course), notice: "Course Updated!"
    else
      render :edit, alert: "Error updating post."
    end
  end
  def show
    @text_course=TextCourse.find(params[:id])
  end
  private
  def text_course_params
    params.require(:text_course).permit(:title, :body)
  end

end
