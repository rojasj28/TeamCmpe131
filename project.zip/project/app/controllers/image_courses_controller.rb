class ImageCoursesController < ApplicationController
end
