class CoursesController < ApplicationController
before_action :authenticate_user!
  def index
    if :search
      @courses=Course.search(params[:search]).order("created_at DeSC")
    else
      @courses=Course.all.order('Created_at DESC')
    end

  end
  def show
    @course=Course.find(params[:id])
  end
end
