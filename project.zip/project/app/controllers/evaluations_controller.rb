
  class EvaluationsController < ApplicationController
    before_action :authenticate_user!
    def create
      @evaluation=current_user.evaluations.build(evaluation_params)

      if @evaluation.save
        redirect_to course_path(@evaluation.course_id),notice: 'Evaluation was sucessfully created.'
      else
        redirect_to course_path(@evaluation.course_id), alert:'Error creating Evaluation'
      end
    end

    def index
    @evaluations= Evaluation.all
    end
    def show
    @course = Course.find(params[:id])

    end
    def destroy
      @evaluation = Evaluation.find (params[:id])
        if @evaluation.destroy
          redirect_to course_path(@evaluation.course_id), notice: 'Evaluation Deleted'
        else
          redirect_to course_path(@evaluation.course_id), notice: 'Error Deleting Evaluation'
        end

    end
    def edit
      @evaluation = current_user.evaluations.find(params[:id])
    end
    def update
      @evaluation = current_user.evaluations.find(params[:id])
      if @evaluation.update(evaluation_params)
        redirect_to course_path(@evaluation.course_id), notice: "Evaluation Updated!"
      else
        render :edit, alert: "Error updating Evaluation."
      end
    end
    private
    def evaluation_params
      params.require(:evaluation).permit(:body, :course_id)
    end
  end