class Course < ApplicationRecord

  belongs_to :user
  validates :user_id, presence: true
  validates :type, presence: true
  has_many :evaluations

  def self.search(search)
    where("title LIKE ?", "%#{search}%")

  end
end
