class TextCourse < Course

    validates :title, presence: true, uniqueness: { scope: :title}


    validates :body, presence: true
end
