class ImageCourse < Course
  validates :url, presence: true
end
