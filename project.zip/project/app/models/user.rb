class User < ApplicationRecord
  has_many :subscriptions, :foreign_key =>"follower_id",
                            dependent: :destroy
  has_many :leaders, through: :subscriptions

  has_many :reverse_subscriptions, :foreign_key =>"leader_id",
                                    class_name: 'Subscription',
                                    dependent: :destroy
  has_many :followers, through: :reverse_subscriptions


  has_many :courses, dependent: :destroy
  has_many :text_courses, dependent: :destroy
  has_many :evaluations, dependent: :destroy

  has_secure_password
  validates :email, presence: true, uniqueness: true


  def timeline_user_ids
    leader_ids+[id]
  end

  def following?(leader)
    leaders.include? leader
  end

  def follow!(leader)
    if leader != self && !following?(leader)
      leaders << leader
    end
  end
end
