Rails.application.routes.draw do

  resources :image_courses

  resources :courses
  resources :text_courses
  resources :evaluations
  resources :users
  resources :sessions

  get 'courses/:id', to: 'text_courses#index'
  get 'signup', to: 'users#new', as: 'signup'
  get 'login', to: 'sessions#new', as: 'login'
  get 'logout', to: 'sessions#destroy', as: 'logout'
  root 'welcome#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
